<?php
include('../../../koneksi.php');

$NIP = $_POST['NAMAPEGAWAI'];
$KODEFAK = $_POST['tahun_ajaran'];
$KODEJAB = $_POST['semester'];
$NAMAPEG = $_POST['masa_ujian'];

$SQL = mysqli_query($koneksi, "insert into pengawasdosen values('$NIP','$KODEFAK','$KODEJAB','$NAMAPEG')") or die (mysqli_error($koneksi));
if($SQL){
	header('location:insertview_pengawas_dosen.php');
}
?>