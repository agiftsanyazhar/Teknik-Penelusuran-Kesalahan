<?php
include('../../../koneksi.php');

$NIP = $_GET['NIP'];
$SQL = mysqli_query($koneksi,"DELETE FROM pengawasdosen WHERE NIP='$NIP'") or die (mysqli_error());
if ($SQL) {
    header('location:insertview_pengawas_dosen.php');
}
?>