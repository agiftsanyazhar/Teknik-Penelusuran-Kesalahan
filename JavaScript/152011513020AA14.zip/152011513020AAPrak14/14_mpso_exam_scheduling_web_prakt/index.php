<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0;url=pages/login.php">
<title>Fakultas Vokasi Universitas Airlangga</title>
<script language="javascript">
    window.location.href = "pages/login.php"
</script>
</head>
<body>
Go to <a href="pages/login.php">pages/login.php</a>
</body>
</html>
