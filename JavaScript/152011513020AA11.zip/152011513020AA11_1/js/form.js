// Instantiate form-authentication object
(function () {
  "use strict";

  const authenticationForm = Object.create(AuthenticationForm);
  authenticationForm.init();
})();
